const limpar = document.getElementById('limparPagamento');
let pagamentoDinamico = document.getElementById('pagamentoDinamico');
let precoTotal = 0;
let carrosAte2000 = 0;

limpar.addEventListener('click', () => {
    pagamentoDinamico.innerHTML = "";
    precoTotal = 0;
    carrosAte2000 = 0;
});

function adicionarAoCarrinho(nome, ano, preco) {
    let desconto;
    if (ano <= 2000) {
        desconto = preco * 12 / 100;
        preco -= desconto;
        carrosAte2000++;
    } else {
        desconto = preco * 7 / 100;
        preco -= desconto;
    }
    precoTotal += Number(preco);

    const mensagem = `<p>Você comprou um ${nome} do ano ${ano}. Ele custa R$${preco.toLocaleString('pt-BR')} reais</p>`;
    aparecerMensagem(mensagem)
}

function aparecerMensagem(mensagem) {
    pagamentoDinamico.innerHTML += mensagem;
}

function realizarPagamento() {
    alert(`Obrigado por sua compra, você comprou ${carrosAte2000} carros anteriores aos anos 2001 e o total da sua compra é de R$${precoTotal.toLocaleString('pt-BR')}`);
}